import imdb_helper_functions as hf


def get_actors_by_movie_soup(cast_page_soup, num_of_actors_limit=None):
    tb = cast_page_soup.find('table', {'class': 'cast_list'})
    actors = tb.find_all('tr', {'class': ['odd', 'even']})
    name_to_link = {}
    for i, a in enumerate(actors):
        if num_of_actors_limit and i >= num_of_actors_limit:
            break

        info = a.find_all('a')[1]
        actor_name = info.text.strip()
        link = info['href']
        name_to_link[actor_name] = link

    return [(k, v) for k, v in name_to_link.items()]


def get_movies_by_actor_soup(actor_page_soup, num_of_movies_limit=None):
    node = actor_page_soup.find('div', id='filmo-head-actor')
    if not node:
        node = actor_page_soup.find('div', id='filmo-head-actress')

    tb = node.findNext('div')
    filmos = tb.find_all('div', {'class': ['filmo-row odd', 'filmo-row-even']})
    name_to_link = {}
    counter = 0
    for f in filmos:
        if num_of_movies_limit and counter >= num_of_movies_limit:
            break

        info = f.find_all('a')
        if any(x in f.text for x in hf.MOVIE_FILTERS):
            continue

        title = info[0]
        name = title.text
        link = title['href']
        name_to_link[name] = link
        counter += 1

    return [(k, v) for k, v in name_to_link.items()]


def get_movie_distance(actor_start_url, actor_end_url,
                       num_of_actors_limit=None, num_of_movies_limit=None):
    pass


def get_movie_descriptions_by_actor_soup(actor_page_soup):
    pass


if __name__ == '__main__':
    import requests
    from bs4 import BeautifulSoup

    title_page = requests.get('https://www.imdb.com/title/tt2382320/fullcredits/')
    title_page_bs = BeautifulSoup(title_page.text, features="html.parser")
    print(get_actors_by_movie_soup(title_page_bs, 1))
    print(get_actors_by_movie_soup(title_page_bs, 3))
    print(get_actors_by_movie_soup(title_page_bs))

    actor_page = requests.get('https://www.imdb.com/name/nm0185819/')
    actor_page_soup = BeautifulSoup(actor_page.text, features="html.parser")
    print(get_movies_by_actor_soup(actor_page_soup, 1))
    print(get_movies_by_actor_soup(actor_page_soup, 3))
    print(get_movies_by_actor_soup(actor_page_soup))

    actress_page = requests.get('https://www.imdb.com/name/nm2244205')
    actress_page_soup = BeautifulSoup(actress_page.text, features="html.parser")
    print(get_movies_by_actor_soup(actress_page_soup, 1))
    print(get_movies_by_actor_soup(actress_page_soup, 3))
    print(get_movies_by_actor_soup(actress_page_soup))
