MOVIE_FILTERS = ['(TV Series)', '(TV Special)', '(announced)', '(completed)', '(Video Game)', '(Short) ',
                 '(TV Mini Series)', '(Video short)', '(Video)', '(TV Movie)']
